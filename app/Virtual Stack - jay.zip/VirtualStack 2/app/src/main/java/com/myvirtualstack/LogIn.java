package com.myvirtualstack;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class LogIn extends AppCompatActivity {
    private Button landingpageBtn;
    private Button returnBtn;

    private String user;
    private String pass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_in);

        // Collecting button references
        landingpageBtn = findViewById(R.id.logBtn2);
        returnBtn = findViewById(R.id.loginRtrnBtn);

        // Action listeners
        landingpageBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // COLLECTING EDITTEXT
                EditText a = findViewById(R.id.user);
                user = a.getText().toString();

                a = findViewById(R.id.pass);
                pass = a.getText().toString();

                // API MAGIC GOES HERE

                // SETTING UP INTENTS
                Intent intentTrain = new Intent(LogIn.this,LandingPage.class);
                Bundle bundleTrain = new Bundle();

                bundleTrain.putString("NAME", "LogIn Tester");
                bundleTrain.putString("OCCUPATION", "LogIn Uni");
                bundleTrain.putString("ADDRESS", "123 LogIn ln.");
                bundleTrain.putString("PHONE", "106-420-6969");
                bundleTrain.putString("EMAIL", "login@email.com");

                intentTrain.putExtras(bundleTrain);
                startActivity(intentTrain);
            }
        });
        returnBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}
