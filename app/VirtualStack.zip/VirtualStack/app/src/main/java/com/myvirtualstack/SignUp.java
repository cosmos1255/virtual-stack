package com.myvirtualstack;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.view.View;
import android.content.Intent;
import android.widget.EditText;

public class SignUp extends AppCompatActivity {
    private Button signupBtn;
    private Button returnBtn;
    public String user;
    public String pass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        // Collecting button references
        signupBtn = findViewById(R.id.signBtn2);
        returnBtn = findViewById(R.id.signupRtrnBtn);

        // Collecting EditText references
        EditText a = findViewById(R.id.newUser);
        user = a.getText().toString();

        a = findViewById(R.id.newPass);
        pass = a.getText().toString();

        // Action Listeners
        signupBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(SignUp.this, CardCreation.class));
            }
        });
        returnBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            }
        });
    }
}
