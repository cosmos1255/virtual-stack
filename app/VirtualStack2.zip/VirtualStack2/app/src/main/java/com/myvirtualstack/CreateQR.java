package com.myvirtualstack;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class CreateQR extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_qr);
    }
}
