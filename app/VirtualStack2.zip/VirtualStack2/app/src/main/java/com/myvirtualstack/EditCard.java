package com.myvirtualstack;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class EditCard extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_card);
    }
}
