package com.myvirtualstack;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class EditCard extends AppCompatActivity {
    private Button editBtn;

    private String myName;
    private String myCompany;
    private String myAddress;
    private String myPhone;
    private String myEmail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_card);

        editBtn = findViewById(R.id.submitBtn);
        editBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent returnIntent = new Intent();
                Bundle extra = new Bundle();

                // Connecting EditText
                EditText a = findViewById(R.id.editMyName);
                myName = a.getText().toString();

                a = findViewById(R.id.editMyCompany);
                myCompany = a.getText().toString();

                a = findViewById(R.id.editMyAddress);
                myAddress = a.getText().toString();

                a = findViewById(R.id.editMyPhone);
                myPhone = a.getText().toString();

                a = findViewById(R.id.editMyEmail);
                myEmail = a.getText().toString();

                // SETTING UP RETURN INTENT
                extra.putString("RETURN_NAME", myName);
                returnIntent.putExtras(extra);

                // API MAGIC GOES HERE

                setResult(1, returnIntent);
                finish();
            }
        });
    }
}