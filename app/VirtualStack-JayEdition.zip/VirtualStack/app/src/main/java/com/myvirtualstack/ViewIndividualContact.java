package com.myvirtualstack;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ViewIndividualContact extends AppCompatActivity {
    private String cardName;
    private String cardCompany;
    private String cardAddress;
    private String cardPhone;
    private String cardemail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_individual_contact);
    }
}
